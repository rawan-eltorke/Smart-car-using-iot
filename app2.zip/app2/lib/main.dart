import 'package:flutter/material.dart';
import 'login_page.dart';
import 'theme_notifier.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'mqtt_service.dart'; // Import your MQTT service

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeNotifier()),
        ChangeNotifierProvider(create: (_) => MqttService()), // Add MqttService here
      ],
      child: CarControlApp(),
    ),
  );
}

class CarControlApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeNotifier>(
      builder: (context, themeNotifier, child) {
        return MaterialApp(
          title: 'Car Control',
          theme: themeNotifier.isDarkMode
              ? ThemeData.dark().copyWith(
                  primaryColor: Colors.teal,
                  appBarTheme: AppBarTheme(
                    backgroundColor: Colors.teal,
                  ),
                  bottomAppBarTheme: BottomAppBarTheme(
                    color: Colors.teal,
                  ),
                  bottomNavigationBarTheme: BottomNavigationBarThemeData(
                    backgroundColor: Colors.teal,
                    selectedItemColor: Colors.white,
                    unselectedItemColor: Colors.grey,
                  ),
                  elevatedButtonTheme: ElevatedButtonThemeData(
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: Colors.deepPurple,
                      shape: StadiumBorder(),
                      padding:
                          EdgeInsets.symmetric(horizontal: 50, vertical: 10),
                    ),
                  ),
                  iconTheme: IconThemeData(
                    color: Colors.white,
                  ),
                )
              : ThemeData.light().copyWith(
                  primaryColor: Colors.teal,
                  appBarTheme: AppBarTheme(
                    backgroundColor: Colors.teal,
                  ),
                  bottomAppBarTheme: BottomAppBarTheme(
                    color: Colors.teal,
                  ),
                  bottomNavigationBarTheme: BottomNavigationBarThemeData(
                    backgroundColor: Colors.teal,
                    selectedItemColor: Colors.black,
                    unselectedItemColor: Colors.grey,
                  ),
                  elevatedButtonTheme: ElevatedButtonThemeData(
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: Colors.deepPurple,
                      shape: StadiumBorder(),
                      padding:
                          EdgeInsets.symmetric(horizontal: 50, vertical: 10),
                    ),
                  ),
                  iconTheme: IconThemeData(
                    color: Colors.black,
                  ),
                ),
          home: LoginPage(),
        );
      },
    );
  }
}
