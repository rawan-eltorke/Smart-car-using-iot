import 'package:flutter/material.dart';

class PrivacyPolicyPage extends StatelessWidget {
  const PrivacyPolicyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Privacy Policy'),
        backgroundColor: Colors.deepPurpleAccent,
      ),
      body: const Padding(
        padding: EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Privacy Policy for Smart Car App',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              Text(
                'Effective Date: [14/9/2024]',
                style: TextStyle(fontSize: 18),
              ),
              SizedBox(height: 20),
              Text(
                '1. Introduction\n\n'
                'Welcome to the Smart Car App (the "App"). We are committed to protecting your privacy and ensuring that your personal information is handled in a safe and responsible manner. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our App.\n\n'
                '2. Information We Collect\n\n'
                'We collect information that you voluntarily provide to us when you use the App, including but not limited to:\n'
                '- Personal Information: Your name, email address, and any other contact details you provide when registering or interacting with the App.\n'
                '- Usage Data: Information about how you use the App, such as your interaction with the car\'s sensors, settings, and features.\n'
                '- Device Information: Details about your device, including its model, operating system, and unique device identifiers.\n'
                '- Location Data: GPS location data may be collected to provide location-based features.\n\n'
                '3. How We Use Your Information\n\n'
                'We use the information we collect for the following purposes:\n'
                '- To Provide and Improve the App: To operate and maintain the App, enhance its functionality, and ensure a better user experience.\n'
                '- To Communicate with You: To respond to your inquiries, send you updates, and provide customer support.\n'
                '- To Personalize Your Experience: To tailor content and features according to your preferences and usage patterns.\n'
                '- To Ensure Security: To detect, prevent, and address technical issues, fraud, and unauthorized access.\n\n'
                '4. Sharing Your Information\n\n'
                'We do not sell or rent your personal information to third parties. We may share your information in the following circumstances:\n'
                '- With Service Providers: We may share your information with third-party service providers who assist us in operating the App and providing its features, such as cloud storage and analytics services.\n'
                '- For Legal Reasons: We may disclose your information if required to do so by law, regulation, or legal process, or if we believe in good faith that such disclosure is necessary to protect our rights or comply with legal obligations.\n\n'
                '5. Security\n\n'
                'We implement reasonable security measures to protect your information from unauthorized access, disclosure, alteration, and destruction. However, no method of transmission over the internet or electronic storage is completely secure, and we cannot guarantee absolute security.\n\n'
                '6. Your Choices\n\n'
                'You have the following choices regarding your information:\n'
                '- Access and Update: You can access and update your personal information through the App settings or by contacting us directly.\n'
                '- Opt-Out: You can opt out of receiving promotional communications from us by following the instructions in those communications or adjusting your notification settings in the App.\n\n'
                '7. Changes to This Privacy Policy\n\n'
                'We may update this Privacy Policy from time to time to reflect changes in our practices or legal requirements. We will notify you of any significant changes by posting the updated policy on the App or through other communication channels.\n\n'
                '8. Contact Us\n\n'
                'If you have any questions or concerns about this Privacy Policy or our data practices, please contact us at:\n\n'
                'Smart Car App Support Team\n'
                'Email: support@smartcarapp.com\n'
                'Address: [Faculty of Computers and Data SCiences , Alexandria University , Ezzbet saad , Alexandria, Egypt]',
                style: TextStyle(fontSize: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
