import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'package:flutter/material.dart';

class MqttService with ChangeNotifier {
  late MqttServerClient client;
  final String broker = '9295ba44a3014ae68d67fc8c4d721df0.s1.eu.hivemq.cloud';
  final int port = 8883;

  String temperature = 'Loading...';
  String flameStatus = 'Loading...';
  String irStatus = 'Loading...';
  String ultrasonicDistance = 'Loading...';
  String humidity = 'Loading...';

  MqttService() {
    client = MqttServerClient(broker, '');
    client.port = port;
    client.logging(on: true);
    client.secure = true;
    client.setProtocolV311();
    client.keepAlivePeriod = 20;
    client.onDisconnected = onDisconnected;
    client.onConnected = onConnected;
  }

  Future<bool> connect(String username, String password) async {
    final connMessage = MqttConnectMessage()
        .withClientIdentifier('flutter_client')
        .authenticateAs(username, password)
        .startClean();
    client.connectionMessage = connMessage;

    try {
      await client.connect();
      if (client.connectionStatus!.state == MqttConnectionState.connected) {
        print('Connected to the broker');
        client.subscribe('temp/reading', MqttQos.atMostOnce);
        client.subscribe('flame/detected', MqttQos.atMostOnce);
        client.subscribe('sensor/reading', MqttQos.atMostOnce);
        client.subscribe('ultrasonic/distance', MqttQos.atMostOnce);
        client.subscribe('humidity/reading', MqttQos.atMostOnce);
        client.updates!.listen((List<MqttReceivedMessage<MqttMessage?>>? c) {
          final recMess = c![0].payload as MqttPublishMessage;
          final pt = MqttPublishPayload.bytesToStringAsString(recMess.payload.message);

          switch (c[0].topic) {
            case 'temp/reading':
              temperature = '$pt °C';
              break;
            case 'flame/detected':
              flameStatus = pt == '1' ? 'Flame Detected' : 'No Flame Detected';
              break;
            case 'sensor/reading':
              irStatus = pt == '1' ? 'Presence Detected' : 'Not Detected';
              break;
            case 'ultrasonic/distance':
              ultrasonicDistance = '$pt m';
              break;
            case 'humidity/reading':
              humidity = '$pt %';
              break;
            default:
              print('Unknown topic: ${c[0].topic}');
          }
          notifyListeners();
        });
        return true;
      } else {
        print('Failed to connect, status: ${client.connectionStatus}');
        return false;
      }
    } catch (e) {
      print('Exception: $e');
      return false;
    }
  }

  void disconnect() {
    client.disconnect();
    notifyListeners();
  }

  void onConnected() {
    print('Connected');
    notifyListeners();
  }

  void onDisconnected() {
    print('Disconnected');
    notifyListeners();
  }
}

