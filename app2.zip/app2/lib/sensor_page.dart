import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // Import provider
import 'package:mqtt_client/mqtt_client.dart'; // Import MqttConnectionState
import 'mqtt_service.dart'; // Import the MqttService

class SensorPage extends StatefulWidget {
  const SensorPage({super.key});

  @override
  _SensorPageState createState() => _SensorPageState();
}

class _SensorPageState extends State<SensorPage> {
@override
void initState() {
  super.initState();
  WidgetsBinding.instance.addPostFrameCallback((_) {
    final mqttService = Provider.of<MqttService>(context, listen: false);
    mqttService.connect('Mahmoud', 'M123456m'); // Add your actual credentials here
  });
}

  @override
  Widget build(BuildContext context) {
    final mqttService = Provider.of<MqttService>(context); // Get the MqttService instance
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Sensor Data'),
        backgroundColor: theme.primaryColor,
      ),
      body: mqttService.client.connectionStatus!.state != MqttConnectionState.connected
          ? const Center(child: CircularProgressIndicator()) // Show loading spinner while connecting
          : Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.primaryColor, Colors.purpleAccent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSensorCard(
                    context,
                    'Temperature Sensor',
                    'Current Temperature: ${mqttService.temperature}', // Access temperature from MqttService
                    Icons.thermostat,
                    Colors.redAccent,
                  ),
                  const SizedBox(height: 16),
                  _buildSensorCard(
                    context,
                    'Flame Sensor',
                    'Status: ${mqttService.flameStatus}', // Access flameStatus from MqttService
                    Icons.whatshot,
                    Colors.orangeAccent,
                  ),
                  const SizedBox(height: 16),
                  _buildSensorCard(
                    context,
                    'IR Sensor',
                    'Presence: ${mqttService.irStatus}', // Access irStatus from MqttService
                    Icons.visibility,
                    Colors.greenAccent,
                  ),
                  const SizedBox(height: 16),
                  _buildSensorCard(
                    context,
                    'Ultrasonic Sensor',
                    'Distance: ${mqttService.ultrasonicDistance}', // Access ultrasonicDistance from MqttService
                    Icons.radar,
                    Colors.blueAccent,
                  ),
                  const SizedBox(height: 16),
                  _buildSensorCard(
                    context,
                    'Humidity Sensor',
                    'Humidity: ${mqttService.humidity}', // Access humidity from MqttService
                    Icons.water_drop,
                    Colors.blue,
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildSensorCard(
    BuildContext context,
    String title,
    String value,
    IconData icon,
    Color iconColor,
  ) {
    final theme = Theme.of(context);
    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      color: theme.cardColor,
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: iconColor,
          child: Icon(icon, color: Colors.white),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: theme.textTheme.titleLarge?.color,
          ),
        ),
        subtitle: Text(
          value,
          style: TextStyle(color: theme.textTheme.titleMedium?.color),
        ),
      ),
    );
  }

  @override
  void dispose() {
    final mqttService = Provider.of<MqttService>(context, listen: false);
    mqttService.disconnect(); // Disconnect using the MqttService
    super.dispose();
  }
}
