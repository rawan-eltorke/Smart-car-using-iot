import 'package:flutter/material.dart';
import 'sensor_page.dart';
import 'settings_page.dart';
import 'profile_page.dart';
import 'package:mqtt_client/mqtt_client.dart' as mqtt;

class HomePage extends StatefulWidget {
  final String email;

  HomePage({required this.email});

   @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late mqtt.MqttClient client;

  @override
  void initState() {
    super.initState();
   // _connectToMqtt();
  }
/*
  Future<void> _connectToMqtt() async {
    client = mqtt.MqttClient(
        '9295ba44a3014ae68d67fc8c4d721df0.s1.eu.hivemq.cloud', '');
    client.port = 8883;

    try {
      await client.connect('Mahmoud', 'M123456m');
      print('Connected to MQTT broker');
    } catch (e) {
      print('Failed to connect to MQTT broker: $e');
    }

    client.onDisconnected = _onDisconnected;
  }

  void _onDisconnected() {
    print('Disconnected from MQTT broker');
  }
*/
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Menu'),
        backgroundColor: Colors.deepPurpleAccent,
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.deepPurpleAccent,
              Colors.blueAccent,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: ListView(
          children: [
            _buildMenuItem(
              context,
              'Sensor Page',
              Icons.sensor_window,
              () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SensorPage()),
              ),
            ),
            SizedBox(height: 15),
            _buildMenuItem(
              context,
              'Settings Page',
              Icons.settings,
              () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SettingsPage()),
              ),
            ),
            SizedBox(height: 15),
            _buildMenuItem(
              context,
              'Profile Page',
              Icons.person,
              () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ProfilePage(email: widget.email)),
              ),
            ),
            // Add more menu items here if needed
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: Colors.deepPurpleAccent,
        unselectedItemColor: Colors.grey,
        showSelectedLabels: true,
        showUnselectedLabels: true,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.directions_car),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.sensor_window),
            label: 'Sensors',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        onTap: (index) {
          if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => SensorPage()),
            );
          } else if (index == 2) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => SettingsPage()),
            );
          } else if (index == 3) {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ProfilePage(email: widget.email)),
            );
          }
        },
      ),
    );
  }

  // Menu item widget
  Widget _buildMenuItem(
      BuildContext context, String title, IconData icon, VoidCallback onTap) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 8,
      child: ListTile(
        leading: Icon(icon, color: Colors.deepPurpleAccent, size: 40),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        onTap: onTap,
      ),
    );
  }
}
