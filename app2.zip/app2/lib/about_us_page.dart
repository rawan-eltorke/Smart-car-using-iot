import 'package:flutter/material.dart';

class AboutUsPage extends StatelessWidget {
  const AboutUsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About Us'),
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'About the Smart Car Project',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            const Text(
              'The Smart Car Project is an innovative initiative to create a fully integrated vehicle system utilizing advanced sensor technologies. Our application allows users to monitor and control various aspects of the car, including temperature, flame detection, and distance measurement using a Flutter app. The project aims to enhance vehicle safety, efficiency, and user experience through smart technology integration.',
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            const Text(
              'Meet Our Team:',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            _buildTeamMember(
              'Marawan Mahmoud',
              'marawan@gmail.com',
            ),
            _buildTeamMember(
              'Rawan Eltorke',
              'rawan@gmail.com',
            ),
            _buildTeamMember(
              'Kenzy Abd Elkreem',
              'kenzy@gmail.com',
            ),
            _buildTeamMember(
              'Shahd Ahmed',
              'shahd@gmail.com',
            ),
            _buildTeamMember(
              'Mona Adel',
              'mona@gmail.com',
            ),
            _buildTeamMember(
              'Mahmoud Essa',
              'mahmoud@gmail.com',
            ),
          ],
        ),
      ),
    );
  }

  // Widget to display team member details
  Widget _buildTeamMember(String name, String email) {
    return Padding(
      padding: const EdgeInsets.symmetric(
          vertical: 10), // Increased vertical padding
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.person, color: Colors.deepPurpleAccent, size: 30),
          const SizedBox(width: 15), // Increased space between icon and text
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                Text(
                  email,
                  style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
